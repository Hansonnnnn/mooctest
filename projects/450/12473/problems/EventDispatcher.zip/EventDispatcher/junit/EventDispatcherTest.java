

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class EventDispatcherTest {
	private EventDispatcher dispatcher;
	
	@Before
	public void setUp() throws Exception {
		dispatcher = new EventDispatcher();
	}

	@Test
	public void testSingleEvent() {
		final String diskMsg = "Disk corruption!";
		dispatcher.register("hardware", new Observer() {
			@Override
			public void onEvent(String event, String msg) {
				assertEquals("hardware", event);
				assertEquals(diskMsg, msg);
			}
		});
		dispatcher.emit("hardware", diskMsg);
	}

	@Test
	public void testIrrelevant() {
		final String diskMsg = "Disk corruption!";
		dispatcher.register("hardware", new Observer() {
			@Override
			public void onEvent(String event, String msg) {
				assertEquals("hardware", event);
				assertEquals(diskMsg, msg);
			}
		});
		dispatcher.register("os", new Observer() {
			@Override
			public void onEvent(String event, String msg) {
				// ���Observer��Ӧ���յ��κ��¼�
				fail();
			}
		});
		dispatcher.emit("hardware", diskMsg);
	}

	@Test
	public void testMultipleEvent() {
		final String diskMsg = "Disk corruption!";
		final String networkMsg = "Wifi connected.";
		Observer observer = new Observer() {
			@Override
			public void onEvent(String event, String msg) {
				if( event.equals("hardware") ){
					assertEquals(diskMsg, msg);
				}else if( event.equals("network") ){
					assertEquals(networkMsg, msg);
				}
			}
		};
		// ͬһ��observerע���������¼�
		dispatcher.register("hardware", observer);
		dispatcher.register("network", observer);
		
		dispatcher.emit("hardware", diskMsg);
		dispatcher.emit("network", networkMsg);
	}
	
	@Test
	public void testMultipleObserver() {
		final String diskMsg = "Disk corruption!";
		final int[] handled = new int[1];
		final int observerCount = 100;
		
		// ����100��observer
		for(int i=0; i<observerCount; i++){
			dispatcher.register("hardware", new Observer(){
				@Override
				public void onEvent(String event, String msg) {
					assertEquals("hardware", event);
					assertEquals(diskMsg, msg);
					handled[0]++;
				}
			});
		}
		
		dispatcher.emit("hardware", diskMsg);
		assertEquals(observerCount, handled[0]);
	}
}
