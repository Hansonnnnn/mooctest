//Write a program to extract each digit from an int, in the reverse order. 
//For example, if the int is 1542, the output shall be 2451, with a comma separating the digits.
//Hints: Use n % 10 to extract a digit; and n = n / 10 to discard the last digit.
public class Digits {
	
    //modify and complete the program
	public static int reverse(int n) {
		while (n > 0) {
			int digit = n % 10; // Extract the last digit

			n = n / 10; // Drop last digit and repeat the loop
		}
		return -1;
	}

}
