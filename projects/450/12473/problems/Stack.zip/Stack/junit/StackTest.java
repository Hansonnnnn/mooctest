

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class StackTest {
	private Stack stack;
	
	@Before
	public void setUp() throws Exception {
		stack = new Stack();
	}

	@Test
	public void test() {
		stack.push(10);
		stack.push(20);
		stack.push(30);
		
		assertEquals(30, stack.pop());
		assertEquals(20, stack.pop());
	}

}
