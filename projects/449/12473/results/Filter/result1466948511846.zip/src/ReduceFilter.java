

public class ReduceFilter implements Filter {

	@Override
	public int[] pipe(int[] nums) {
		int[] map = new int[100];
		for(int i=0; i<map.length; i++){
			map[i] = 0;
		}
		
		// ��ͬ�������м���
		int count = 0;
		for(int num: nums){
			if( map[num] == 0 ){
				count++;
				map[num] = 1;
			}
		}
		
		int[] res = new int[count];
		int pos = 0;
		for(int num: nums){
			if( map[num] > 0 ){
				res[pos++] = num;
				map[num] = 0;
			}
		}
		
		return res;
	}
}
