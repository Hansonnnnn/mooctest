

public class CutFilter implements Filter {
	private int start = -1;
	private int end = -1;
	
	public CutFilter(String rangeStr) {
		String[] parts = rangeStr.split(" ");
		String[] range = parts[1].split("-");
		start = Integer.parseInt(range[0]);
		end = Integer.parseInt(range[1]);
	}

	@Override
	public int[] pipe(int[] nums) {
		int[] res = new int[end - start];
		int pos = 0;
		for(int i=start; i<end; i++){
			res[pos++] = nums[i];
		}
		
		return res;
	}

}
