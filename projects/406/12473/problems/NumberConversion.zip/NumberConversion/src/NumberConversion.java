/**
 * Exercise NumberConversion: Write a method call toRadix() which converts a positive integer from one radix into another. The method has the following header:
 * public static String toRadix(String in, int inRadix, int outRadix)  // The input and output are treated as String.
 * <p/>
 * toRadix("A1B2", 16, 2) will return  "1010000110110010"
 */
public class NumberConversion {
	public static String toRadix(String in, int inRadix, int outRadix) {
		assert inRadix == 2 || inRadix == 8 || inRadix == 10 || inRadix == 16;
		assert outRadix == 2 || outRadix == 8 || outRadix == 10 || outRadix == 16;
		return null;
	}
}
