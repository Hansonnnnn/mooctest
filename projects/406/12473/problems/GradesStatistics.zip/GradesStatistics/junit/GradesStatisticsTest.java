
import static org.junit.Assert.*;

import org.junit.Test;

public class GradesStatisticsTest {

	@Test
	public void testMaxGrade1() {
		GradesStatistics info=new GradesStatistics();
		info.numOfStudents=3;
		info.grades=new int[]{10,20,30,40};
		assertEquals(40,info.maxGrade());
	}
	
	@Test
	public void testMaxGrade2() {
		GradesStatistics info=new GradesStatistics();
		info.numOfStudents=1;
		info.grades=new int[]{30};
		assertEquals(30,info.maxGrade());
	}
	
	@Test
	public void testMaxGrade3() {
		GradesStatistics info=new GradesStatistics();
		info.numOfStudents=3;
		info.grades=new int[]{99,30,120};
		assertEquals(99,info.maxGrade());
	}

	@Test
	public void testMinGrade1() {
		GradesStatistics info=new GradesStatistics();
		info.numOfStudents=3;
		info.grades=new int[]{10,20,30,40};
		assertEquals(10,info.minGrade());
	}

	@Test
	public void testMinGrade2() {
		GradesStatistics info=new GradesStatistics();
		info.numOfStudents=2;
		info.grades=new int[]{20,0};
		assertEquals(0,info.minGrade());
	}
	
	@Test
	public void testMinGrade3() {
		GradesStatistics info=new GradesStatistics();
		info.numOfStudents=3;
		info.grades=new int[]{44,20,-10};
		assertEquals(20,info.minGrade());
	}
}
