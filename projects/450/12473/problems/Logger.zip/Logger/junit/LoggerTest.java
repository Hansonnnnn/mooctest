

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintStream;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;

import org.junit.Before;
import org.junit.Test;

public class LoggerTest {
	private static final String sp = System.getProperty("line.separator");
	private Logger logger;
	private ByteArrayOutputStream os;
	
	@Before
	public void setUp() throws Exception {
		logger = new Logger();
		os = new ByteArrayOutputStream();
		System.setOut(new PrintStream(os));
	}

	@Test
	public void testDebug(){
		logger.setLevel(LogLevel.DEBUG);
		logger.debug("Running code...");
		assertEquals("[DEBUG]Running code..."+sp, os.toString());
	}
	
	@Test
	public void testFilter(){
		logger.setLevel(LogLevel.INFO);
		logger.info("Processing...");
		logger.debug("Running code...");
		
		assertEquals("[INFO]Processing..."+sp, os.toString());
	}
	
	@Test
	public void testSettingOutput() throws IOException{
		OutputStream osm = new ByteArrayOutputStream();
		PrintWriter writer = new PrintWriter(osm);
		logger.setOutput(writer);
		logger.setLevel(LogLevel.DEBUG);
		logger.debug("Running code...");
		
		writer.flush();
		assertEquals("[DEBUG]Running code..."+sp, osm.toString());
		assertEquals("", os.toString());
	}
}
