/*
 * Write a program called Arithmetic that takes three command-line arguments: 
 * two integers followed by an arithmetic operator (+, -, * or /)
 * if the expression's form is not right,output "wrong"
 *  
 * input:
 * "3 2 +"
 * output:
 * "3+2=5"
 */

public class Arithmetic {
	public static String arithmetic(String s) {
		return "";
	}
	
	
}