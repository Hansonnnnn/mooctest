

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class FileSystemTest {
	private FileSystem fs;

	@Before
	public void setUp() throws Exception {
		fs = new FileSystem();
	}

	@Test
	public void testCreate() {
		// �򵥴�������
		String dir = "/usr/local/java/";
		assertTrue(fs.create(dir));
		
		String file = "/usr/local/java/file";
		assertTrue(fs.create(file));
	}

	@Test
	public void testExists() {
		// �ļ�������
		String file = "/usr/local/java/file";
		assertFalse(fs.exists(file));
		assertTrue(fs.create(file));
		assertTrue(fs.exists(file));
		
		// Ŀ¼������
		String dir = "/usr/local/python/";
		assertFalse(fs.exists(dir));
		assertTrue(fs.create(dir));
		assertTrue(fs.exists(dir));
	}
	
	@Test
	public void testParent() {
		// ��Ŀ¼�Ĵ�����
		assertTrue(fs.create("/usr/local/foo"));
		assertTrue(fs.exists("/usr/local"));
	}
	
	@Test
	public void testDuplicate() {
		// �ظ������ļ�
		String file = "/usr/local/java/file";
		assertTrue(fs.create(file));
		assertFalse(fs.create(file));
		
		// �ļ�������Ŀ¼ͬ��
		String file2 = "/usr/local"; // �ļ��Ľ�βû��/
		assertFalse(fs.create(file2));
	}
	
	@Test
	public void testRoot() {
		// ��Ŀ¼һֱ����
		assertTrue(fs.exists("/"));
		assertFalse(fs.create("/"));
	}
}
