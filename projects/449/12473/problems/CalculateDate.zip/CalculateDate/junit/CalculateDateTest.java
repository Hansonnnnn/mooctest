import static org.junit.Assert.*;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class CalculateDateTest {
	PrintStream console = null;
	ByteArrayOutputStream bytes = null;
	String sep;
	CalculateDate calculateDate;
	
	@Before
	public void setUp() throws Exception {
		calculateDate = new CalculateDate();
		bytes = new ByteArrayOutputStream();
		console = System.out;
		System.setOut(new PrintStream(bytes));
		sep = System.getProperty("line.separator");
	}

	@After
	public void tearDown() throws Exception {
		bytes.close();
		System.setOut(console);
	}
	
	@Test
	public void test1() {
		MyDate date1 = new MyDate(2016, 12, 3);
		MyDate date2 = new MyDate(2016, 12, 5);
		int day = calculateDate.calculate(date1, date2);
		assertEquals(2, day);
	}
	
	@Test
	public void test2() {
		MyDate date1 = new MyDate(2016, 12, 3);
		MyDate date2 = new MyDate(2013, 2, 5);
		int day = calculateDate.calculate(date1, date2);
		assertEquals(1400, day);
	}
	
	@Test
	public void test3() {
		MyDate date1 = new MyDate(1992, 6, 3);
		MyDate date2 = new MyDate(2016, 12, 5);
		int day = calculateDate.calculate(date1, date2);
		assertEquals(8952, day);
	}
	
	@Test
	public void test4() {
		MyDate date1 = new MyDate(1916, 12, 3);
		MyDate date2 = new MyDate(1803, 2, 5);
		int day = calculateDate.calculate(date1, date2);
		assertEquals(41577, day);
	}
	
	@Test
	public void test5() {
		MyDate date1 = new MyDate(1912, 12, 3);
		MyDate date2 = new MyDate(2016, 12, 5);
		int day = calculateDate.calculate(date1, date2);
		assertEquals(37988, day);
	}
}
