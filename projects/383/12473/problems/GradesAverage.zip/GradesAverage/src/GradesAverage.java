/**
 * 写一个方法computeGradesAverage，计算并返回给定一组学生分数的平均数
 * 
 * 如果任意一个学生的分数小于0或者大于100则返回-1
 * 如果是数组没有元素则返回0
 */

public class GradesAverage{	
	public double computeGradesAverage(int grade[]){
		return 0.0;
	}
}