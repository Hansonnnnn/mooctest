import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;


public class BullsAndCowsTest {
	PrintStream console;
	ByteArrayOutputStream bytes;
	static String SEPARATOR = System.getProperty("line.separator");
	
	@org.junit.Before
	public void setUp() throws Exception{
		bytes = new ByteArrayOutputStream();
		console = System.out;
		System.setOut(new PrintStream(bytes));
	}
	
	@org.junit.After
	public void tearDown() throws Exception{
		System.setOut(console);
	}
	
	@org.junit.Test
	public void testBullsAndCows1(){
		BullsAndCows bac = new BullsAndCows();
		int secret = bac.getSecret();
		assertTrue(secret >= 1000 && secret <= 9999);
	}

	@org.junit.Test
	public void testCompare1(){
		BullsAndCows bac = new BullsAndCows(5234);
		assertEquals(bac.compare(5346),"1A2B");
	}
	
	@org.junit.Test
	public void testCompare2(){
		BullsAndCows bac = new BullsAndCows(5234);
		assertEquals(bac.compare(5234),"4A0B");
	}
	
	@org.junit.Test
	public void testCompare3(){
		BullsAndCows bac = new BullsAndCows(3210);
		assertEquals(bac.compare(1023),"0A4B");
	}
	
	@org.junit.Test
	public void testPlayGame1(){
		BullsAndCows bac = new BullsAndCows(5234);
		bac.playGame();
		String[] out = bytes.toString().split(SEPARATOR);
		assertTrue(out.length >= 7 && out.length <=30004);
		assertEquals(out[0],"Game Start");
		assertEquals(out[1],"----------");
		assertEquals(out[out.length - 2],"You win!You took "+ (out.length - 4) / 3 +" steps.");
		assertEquals(out[out.length - 1],"----------");
		
		for(int i = 0; i < (out.length - 4) / 3; i++){
			String[] guess = out[2 + i * 3].split(":");
			String[] result = out[3 + i * 3].split(":");
			String _ = out[4 + i * 3];
			assertEquals(_,"----------");
			assertTrue(guess.length == 2 && result.length == 2);
			assertEquals(guess[0], "Guess");
			assertEquals(result[0], "Result");
			assertEquals(result[1],bac.compare(Integer.parseInt(guess[1])));
			assertTrue(Integer.parseInt(guess[1]) >= 1000 && Integer.parseInt(guess[1]) <= 9999);
			for(int j = 0; j < 4; j++){
				for(int k = 3; k > j; k--){
					if(guess[1].charAt(j) == guess[1].charAt(k)) {
						assertTrue(false);
					}
				}
			}
		}
	}
	
	@org.junit.Test
	public void testPlayGame2(){
		BullsAndCows bac = new BullsAndCows(7890);
		bac.playGame();
		String[] out = bytes.toString().split(SEPARATOR);
		assertTrue(out.length >= 7 && out.length <=30004);
		assertEquals(out[0],"Game Start");
		assertEquals(out[1],"----------");
		assertEquals(out[out.length - 2],"You win!You took "+ (out.length - 4) / 3 +" steps.");
		assertEquals(out[out.length - 1],"----------");
		
		for(int i = 0; i < (out.length - 4) / 3; i++){
			String[] guess = out[2 + i * 3].split(":");
			String[] result = out[3 + i * 3].split(":");
			String _ = out[4 + i * 3];
			assertEquals(_,"----------");
			assertTrue(guess.length == 2 && result.length == 2);
			assertEquals(guess[0], "Guess");
			assertEquals(result[0], "Result");
			assertEquals(result[1],bac.compare(Integer.parseInt(guess[1])));
			assertTrue(Integer.parseInt(guess[1]) >= 1000 && Integer.parseInt(guess[1]) <= 9999);
			for(int j = 0; j < 4; j++){
				for(int k = 3; k > j; k--){
					if(guess[1].charAt(j) == guess[1].charAt(k)) {
						assertTrue(false);
					}
				}
			}
		}
	}

}
