import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;


public class PipeTest {
	private PipeProcessor processor;
	
	@Before
	public void setUp() throws Exception {
		processor = new PipeProcessor();
	}

	@Test
	public void test1() {
		String command = "sort";
		int[] nums = {3,5,1,9,9,10,12};
		nums = processor.process(nums, command);
		
		int[] answer = {1,3,5,9,9,10,12};
		assertArrayEquals(answer, nums);
	}
	
	@Test
	public void test2() {
		String command = "sort | reverse";
		int[] nums = {3,5,1,9,9,10,12};
		nums = processor.process(nums, command);
		
		int[] answer = {12,10,9,9,5,3,1};
		assertArrayEquals(answer, nums);
	}
	
	@Test
	public void test3() {
		String command = "sort | cut 1-4";
		int[] nums = {3,5,1,9,9,10,12};
		nums = processor.process(nums, command);
		
		int[] answer = {3,5,9};
		assertArrayEquals(answer, nums);
	}
	
	@Test
	public void test4() {
		String command = "reduce";
		int[] nums = {3,5,1,9,9,10,12};
		nums = processor.process(nums, command);
		
		int[] answer = {3,5,1,9,10,12}; // 顺序不能�?		assertArrayEquals(answer, nums);
	}
}
