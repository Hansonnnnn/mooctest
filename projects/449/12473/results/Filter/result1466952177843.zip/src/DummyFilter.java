

public class DummyFilter implements Filter {

	@Override
	public int[] pipe(int[] nums) {
		return nums;
	}

}
