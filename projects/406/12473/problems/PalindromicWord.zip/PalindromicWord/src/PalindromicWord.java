/*A word that reads the same backward as forward is called a palindrome, e.g., "mom", "dad", "racecar", "madam", 
 * and "Radar" (case-insensitive). Write a program called TestPalindromicWord, 

A phrase that reads the same backward as forward is also called a palindrome, e.g., "Madam, I'm Adam", 
"A man, a plan, a canal - Panama!" (ignoring punctuation ,capitalization and space). 


*/
public class PalindromicWord{
	/**
	 * 判断s是否是回文
	 * @param s
	 * @return 真或假
	 */
	public static boolean isPalindromicWord(String s){
		return false;
	}
}