

import java.util.Arrays;

public class SortFilter implements Filter {

	@Override
	public int[] pipe(int[] nums) {
		Arrays.sort(nums);
		return nums;
	}
}
