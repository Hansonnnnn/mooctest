

public class ReverseFilter implements Filter {

	@Override
	public int[] pipe(int[] nums) {
		int len = nums.length;
		for(int i=0; i<len/2; i++){
			int tmp = nums[i];
			nums[i] = nums[len-1-i];
			nums[len-1-i] = tmp;
		}
		
		return nums;
	}
}
