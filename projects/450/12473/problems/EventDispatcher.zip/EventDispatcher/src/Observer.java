

public interface Observer {
	public void onEvent(String event, String msg);
}
