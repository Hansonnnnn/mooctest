

import java.util.LinkedList;
import java.util.List;

/**
 * 管道(Pipe)是操作系统中一个很重要的机制。
 * 直观上说，管道的作用就是可以把多条命令连接起来，把前一条命令的输出连接到后一条命令的输入上。
 * 这样就可以很简单地把多条简单命令任意组合成你想要的复合命令。
 * 
 * 现在我们来模拟实现一个管道机制。我们要做的是是对一组数字进行过滤处理。
 * 我们有以下几条过滤命令：
 * 1. sort，对数组进行排序
 * 2. reverse，把数组中的各数字倒过来，比如[1,8,4]变成[4,8,1]
 * 3. cut, 把一个数组中指定范围的数字截取出来，其余丢弃。
 * 4. reduce，去除数组中重复的数字，只保留第一次出现的数字。比如[4,12,3,3,1]变成[4,12,3,1]
 * 
 * 现在需要实现本类的process方法，传入一个数字数组和一条命令字符串，输出过滤处理后的结果。
 * 例如(伪码表示)：
 * process([3,5,1,9], "sort | reverse") // [9,5,3,1]
 * 
 * | 即管道操作符，在这里把sort和reverse命令连接了起来，把输入数组先进行了排序，然后再反转，最后输出。
 * 
 * 再比如：
 * process([2,2,1,8,8,9,9,10], "reduce | cut 1-4") // [1,8,9]
 * 
 * 先去除重复元素得到[2,1,8,9,10]，然后再取出索引在[1,4)之间的元素，得到[1,8,9]
 * 注意cut命令的两个索引参数是前开后闭的
 * 
 * 请使用Filter接口定义各个Filter子类完成功能。
 * 
 * 注意：
 * 1. 命令字符串中可能存在空格
 * 2. 为了简单起见，所有的数字范围在[0,100)之间
 */
public class PipeProcessor {
	private List<Filter> pipes = new LinkedList<>();
	
	public int[] process(int[] nums, String command) {
		buildPipes(command);
		
		// pipe开始处理
		int[] res = nums;
		for(Filter pipe: pipes){
			res = pipe.pipe(res);
		}
		return res;
	}
	
	private void buildPipes(String command){
		String[] pipeStrs= command.split("\\|");
		Filter pipe = null;
		
		for(String str: pipeStrs){
			str = str.trim();
			
			if( str.startsWith("sort") )
				pipe = new SortFilter();
			else if( str.startsWith("reverse") )
				pipe = new ReverseFilter();
			else if( str.startsWith("cut") )
				pipe = new CutFilter(str);
			else if( str.startsWith("reduce") )
				pipe = new ReduceFilter();
			else
				pipe = new DummyFilter();
			
			pipes.add(pipe);
		}
	}
}

/**
 * 注意：可能有空格
 * 数字范围在[0,100)
 */