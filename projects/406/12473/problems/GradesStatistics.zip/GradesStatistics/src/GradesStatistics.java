/**
 * 写两个方法maxGrade和minGrade，分别计算并返回一组学生的最高分和最低分。
 * 分数在区间[0,100]内，超出此区间的值需要被忽略。
 * 
 * 成员变量numOfStudents和grades已设置，请在此前提下尝试完成题目。
 */
public class GradesStatistics{
	public int numOfStudents;
	public int grades[];
	
	public int maxGrade(){
		return 0;
	}
	
	public int minGrade(){
		return 0;
	}
}