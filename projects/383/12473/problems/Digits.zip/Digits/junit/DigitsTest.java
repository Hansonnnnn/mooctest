import static org.junit.Assert.*;

import org.junit.Test;


public class DigitsTest {

	@Test
	public void testReverse() {
		int num = Digits.reverse(1542);
		assertEquals(2451,num);
	}

	@Test
	public void testReverse() {
		int num = Digits.reverse(0);
		assertEquals(0,num);
	}

}
