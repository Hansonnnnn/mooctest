
public class GameWinStrategy_HV {
	public Result check(char[][] cells)
	{
		return null;
	}
}
