import static org.junit.Assert.*;
import org.junit.Test;


public class CharacterMovingTest {

	@Test
	public void test1() {
		String[][] map = new String[][]
				{
			{"*", "*", "*", "*"},
			{"*", "32", "79", "e"},
			{"*", "58", "*", "*"},
			{"*", "s", "*", "*"}
				};
		
		assertEquals(30, new CharacterMovingSimulator().ComputeMovingTime(map, 10));	
	}
	
	@Test
	public void test2() {
		String[][] map = new String[][]
				{
			{"e", "69", "*", "*"},
			{"*", "32", "*", "*"},
			{"*", "58", "*", "*"},
			{"*", "33", "25", "s"}
				};
		
		assertEquals(59, new CharacterMovingSimulator().ComputeMovingTime(map, 3));	
	}
	
	@Test
	public void test3() {
		String[][] map = new String[][]
				{
			{"*", "*", "*", "*", "*"},
			{"*", "32", "79", "55", "*"},
			{"*", "58", "*", "99", "*"},
			{"*", "s", "*", "e", "*"},
			{"*", "*", "*", "*", "*"}
				};
		
		assertEquals(69, new CharacterMovingSimulator().ComputeMovingTime(map, 10));	
	}
	
	@Test
	public void test4() {
		String[][] map = new String[][]
				{
			{"e", "07"},
			{"*", "s"}
				};
		
		assertEquals(15, new CharacterMovingSimulator().ComputeMovingTime(map, 0));	
	}
	
	@Test
	public void test5() {
		String[][] map = new String[][]
				{
			{"89", "51", "42", "*", "e"},
			{"53", "*", "13", "*", "72"},
			{"67", "*", "86", "*", "44"},
			{"12", "*", "79", "*", "66"},
			{"s", "*", "01", "63", "75"}
				};
		
		assertEquals(170, new CharacterMovingSimulator().ComputeMovingTime(map, 6));	
	}

}
