import java.util.Calendar;

/*
给定两个日期，计算两个日期之间相差多少天，例如给定两个日期，1993-11-06  1993-11-18，
这两个日期之间相差 12 天。
需要注意的是，输入的两个日期没有先后顺序，假定输入的日期都是合法的。
*/

public class CalculateDate {
	
	//返回两个日期相差的天数
	public int calculate(MyDate date1, MyDate date2){
		//insert code here
		Calendar cal = Calendar.getInstance();  
		cal.set(date1.year, date1.month, date1.day);
        long time1 = cal.getTimeInMillis();               
        cal.set(date2.year, date2.month, date2.day);
        long time2 = cal.getTimeInMillis();       
        long between_days=(time2-time1)/(1000*3600*24);  
          
       return Math.abs((int)between_days);      
	}
}

class MyDate {
	public int year;
	public int month;
	public int day;
	
	public MyDate(int year, int month, int day){
		//insert code here
		this.year = year;
		this.month = month;
		this.day = day;
	}
}