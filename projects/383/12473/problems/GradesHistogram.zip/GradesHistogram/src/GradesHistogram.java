/**
写一个histogram方法，从标准输入流中读入一组数字，然后将这组数据的分布情况输出。

输入数据的格式如下：
numStduents:int
grade1:int grade2:int .... gradeN:int

比如：
15
49 50 51 59 0 5 9 10 15 19 50 55 89 99 100

输出:
0 - 9: ***
10 - 19: ***
20 - 29: 
30 - 39: 
40 - 49: *
50 - 59: *****
60 - 69: 
70 - 79: 
80 - 89: *
90 - 99: **

注意，每一行的 - 两侧都有空格，: 的右侧也有一个空格，每行结束有一个换行符
*/

public class GradesHistogram{
	
	public static void histogram(){

	}	
}











