import static org.junit.Assert.*;
import org.junit.Test;


public class CharacterMovingTest {

	@Test
	public void test1() {
		String[][] map = new String[][]
				{
			{"*", "*", "*", "*"},
			{"*", "32", "79", "e"},
			{"*", "58", "*", "*"},
			{"*", "s", "*", "*"}
				};
				
		String[] effects = new String[]
				{
					"1 1 1 2"	
				};
		
		assertEquals(35, new CharacterMovingSimulator2().ComputeMovingTime(map, 10, effects));	
	}
	
	@Test
	public void test2() {
		String[][] map = new String[][]
				{
			{"e", "07"},
			{"*", "s"}
				};
				
		String[] effects = new String[]
				{
					"1 0 1 3",	
					"2 0 1",
					"3 0 1 5"
				};
		
		assertEquals(30, new CharacterMovingSimulator2().ComputeMovingTime(map, 3, effects));	
	}

}
