public enum Result {
    X_WIN,//X Player wins the game.
    O_WIN,//O Player wins the game.
    DRAW,//No one wins.
    GAMING//Game is not over.
}
