/**
 * Extract the source code of the class Math from the JDK source code 
 * ("$JAVA_HOME" ⇒ "src.zip" ⇒ "Math.java" under folder "java.lang"). 
 * Study how constants such as E and PI are defined. Also study how methods
 * such as abs(), max(), min(), toDegree(), etc, are written.
 * 
 * 
 * 
 */

public class MathStudy{
	/**
	 * 学习Math的abs方法，学会自己实现一个abs方法
	 * @param d
	 * @return 绝对值
	 */
	public static double abs_(double d){
		
		return -1;
	}
	
	
	public static double pi_(){
		return Math.PI;
	}
		
}